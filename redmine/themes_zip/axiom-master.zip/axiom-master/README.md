## Axiom

Axiom is [Redmine](http://www.redmine.org/) theme. It's a low-toned (dark) with green highlights. Enjoy!

* Compatible with Redmine 2.0.0+

![Screenshot](https://github.com/hulihanapplications/axiom/raw/master/screenshot.png)

## Installation

Place this directory in `public/themes/axiom`, inside your redmine directory.

Or, if you're lazy and have git on your server:

```sh
cd your-redmine-directory/
cd public/themes
git clone git://github.com/hulihanapplications/axiom.git
```

### License

This work is licensed by the [Creative Commons Attribution 3.0 United States License](http://creativecommons.org/licenses/by/3.0/).

* Author: Dave Hulihan

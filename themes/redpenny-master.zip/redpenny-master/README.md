## Red Penny - Redmine Theme.

### Installation
To install, just clone Red Penny files to your Redmine theme directory "public/themes"

zsh$ cd /path/to/redmine/public/themes

zsh$ git clone http://github.com/themondays/redpenny.git redpenny

### License

* This theme is available under [CC-BY 3.0](http://creativecommons.org/licenses/by/3.0/)

* Font Awesome is available under [SIL OFL 1.1](http://scripts.sil.org/OFL)

### Additional thank for amazing fonts:
Dave Gandy (@byscuits)
Paul D. Hunt
